import requests
import json
from datetime import date
from datetime import datetime
import random

entrada=""
entrada_cliente=""
url_cliente='http://localhost:5000/usuarios'
url_inventario='http://localhost:5000/inventario'
url_compra='http://localhost:5000/compras'
headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}

def agregar_cliente(documento, nombre, apellidos, correo, telefono, direccion):
    datos_cliente={"documento": documento,
                           "nombre": nombre,
                           "apellidos": apellidos,
                           "correo": correo,
                           "telefono": telefono,
                           "direccion": direccion
                           }
            
    mensaje=requests.post(url_cliente, data=json.dumps(datos_cliente), headers=headers)
    return(mensaje.text)

def editar_cliente(nombre, apellidos, correo, telefono, direccion):
    datos_cliente={
                           "nombre": nombre,
                           "apellidos": apellidos,
                           "correo": correo,
                           "telefono": telefono,
                           "direccion": direccion
                           }

    mensaje=requests.put(url_cliente+"/"+documento, data=json.dumps(datos_cliente), headers=headers)
    return(mensaje.text)

def agregar_producto (codigo, nombre, tipo, cantidad, precio):
    datos_producto={
                        "codigo_producto": codigo,
                        "nombre_producto": nombre,
                        "tipo_producto": tipo,
                        "cantidad_disponible": cantidad,
                        "precio": precio
                        }
    mensaje=requests.post(url_inventario, data=json.dumps(datos_producto), headers=headers)
    return(mensaje.text)

def editar_producto (nombre, tipo, cantidad, precio, codigo_producto):
    datos_producto={
                        "nombre_producto": nombre,
                        "tipo_producto": tipo,
                        "cantidad_disponible": cantidad,
                        "precio": precio
                        }
    mensaje=requests.put(url_inventario+"/"+codigo_producto, data=json.dumps(datos_producto), headers=headers)
    return(mensaje.text)

def agregar_compra (idcompra, productos, nombre_cliente, fecha, documento):
    datos_compra ={
                        "idcompra": idcompra,
                        "productos": productos,
                        "nombre_cliente": nombre_cliente,
                        "fecha": fecha,
                        "documento": documento
                        }
    mensaje=requests.post(url_compra, data=json.dumps(datos_compra), headers=headers)
    return(mensaje.text)

def editar_compra (productos, nombre_cliente, fecha, documento):
    datos_compra ={
                        "productos": productos,
                        "nombre_cliente": nombre_cliente,
                        "fecha": fecha,
                        "documento": documento
                        }
    mensaje=requests.put(url_compra+"/"+idcompra, data=json.dumps(datos_compra), headers=headers)
    return (mensaje.text)


    
#PROYECTO FINAL ARQUITECTUTA C/S UTP
#SANTIAGO GONZÁLEZ BEDOYA// DIEGO ALEXANDER AGUDELO

while entrada != "0":
    print("********************************************")
    print("BIENVENIDO")
    print("********************************************")
    print("MENU DE OPCIONES TIENDA:")
    print("1.Opciones Clientes")
    print("2.Opciones Inventario")
    print("3.Opciones Registro Compras")
    print("4.Ingreso a la tienda")
    print("0.SALIR")
    entrada=input("Seleccione opcion: ")

    if entrada== "1":
        print("********************************************")
        print("MENU DE OPCIONES:")
        print("********************************************")
        print("1.Agregar Cliente")
        print("2.Listar Clientes")
        print("3.Consultar Cliente")
        print("4.Eliminar Cliente")
        print("5.Actualizar Cliente")
        print("0.Regresar")
        entrada_cliente=input("Seleccione opcion: ")
        if entrada_cliente == "1":
            documento=input("Escriba su documento: ")
            nombre=input("Escriba su nombre: ")
            apellidos=input("Escriba sus apellidos: ")
            correo=input("Escriba su correo: ")
            telefono=input("Escriba su telefono: ")
            direccion=input("Escriba su direccion: ")
            print (agregar_cliente(documento, nombre, apellidos, correo, telefono, direccion))

            
            
        if entrada_cliente == "2":
            mensaje=requests.get(url_cliente)
            print (mensaje.text)
            
            
        if entrada_cliente == "3":
            documento=input("Escriba el documento del cliente que desea buscar: ")
            mensaje=requests.get(url_cliente+"/"+documento)
            print(mensaje.text)
            
        if entrada_cliente == "4":
            documento=input("Escriba el documento del cliente que desea eliminar: ")
            mensaje=requests.delete(url_cliente+"/"+documento)
            print(mensaje.text)

        if entrada_cliente == "5":
            documento=input("Escriba el documento del cliente que desea editar: ")
            mensaje=requests.get(url_cliente+"/"+documento)
            mensaje=mensaje.json()
            nombre_nuevo=input("Escriba su nuevo nombre: ")
            apellidos_nuevo=input("Escriba sus nuevos apellidos: ")
            correo_nuevo=input("Escriba su nuevo correo: ")
            telefono_nuevo=input("Escriba su nuevo numero telefonico: ")
            direccion_nuevo=input("Escriba su nueva direccion: ")


            if nombre_nuevo == "":
                nombre_nuevo= mensaje["nombre"]
            if apellidos_nuevo =="":
                apellidos_nuevo= mensaje["apellidos"]
            if correo_nuevo == "":
                correo_nuevo=mensaje["correo"]
            if telefono_nuevo == "":
                telefono_nuevo=mensaje["telefono"]
            if direccion_nuevo == "":
                direccion_nuevo = mensaje["direccion"]

            print (editar_cliente(nombre_nuevo, apellidos_nuevo, correo_nuevo, telefono_nuevo, direccion_nuevo))

    

#INVENTARIO


    if entrada== "2":
        print("********************************************")
        print("MENU DE OPCIONES:")
        print("********************************************")
        print("1.Agregar producto")
        print("2.Listar producto")
        print("3.Consultar producto")
        print("4.Eliminar producto")
        print("5.Actualizar producto")
        print("0.Regresar")
        entrada_cliente=input("Seleccione opcion: ")
        if entrada_cliente == "1": 
                codigo_producto=input("Escriba el codigo del producto: ")
                nombre_producto=input("Escriba nombre del producto: ")
                tipo_producto=input("Escriba tipo de producto: ")
                cantidad_disponible=input("Escriba cantidad disponible del producto: ")
                precio=input("Escriba precio del producto: ")
                print (agregar_producto(codigo_producto, nombre_producto, tipo_producto, cantidad_disponible, precio))

        if entrada_cliente == "2":
            mensaje=requests.get(url_inventario)
            print (mensaje.text)
            
            
        if entrada_cliente == "3":
            codigo_producto=input("Escriba el codigo del producto que quiere buscar: ")
            mensaje=requests.get(url_inventario+"/"+codigo_producto)
            print(mensaje.text)
            
        if entrada_cliente == "4":
            documento=input("Escriba codigo del producto que quiere eliminar: ")
            mensaje=requests.delete(url_inventario+"/"+codigo_producto)
            print(mensaje.text)

        if entrada_cliente == "5":
            codigo_producto=input("Escriba codigo del producto que quiere editar: ")
            mensaje=requests.get(url_inventario+"/"+codigo_producto)
            mensaje=mensaje.json()
            nombre_producto_nuevo=input("Escriba el nuevo nombre del producto: ")
            tipo_producto_nuevo=input("Escriba el nuevo tipo de producto: ")
            cantidad_disponible_nuevo=input("Escriba la cantidad disponible: ")
            precio_nuevo=input("Escriba el nuevo precio: ")


            if nombre_producto_nuevo == "":
                nombre_producto_nuevo= mensaje["nombre_producto"]
            if tipo_producto_nuevo =="":
                tipo_producto_nuevo= mensaje["tipo_producto"]
            if cantidad_disponible_nuevo == "":
                cantidad_disponible_nuevo=mensaje["cantidad_disponible"]
            if precio_nuevo == "":
                precio_nuevo=mensaje["precio"]
            

            print (editar_producto(nombre_producto_nuevo, tipo_producto_nuevo, cantidad_disponible_nuevo, precio_nuevo, codigo_producto))
             
#COMPRAS

    if entrada== "3":
        print("********************************************")
        print("MENU DE OPCIONES:")
        print("********************************************")
        print("1.Agregar compras")
        print("2.Listar compras")
        print("3.Consultar compras")
        print("4.Eliminar compras")
        print("5.Actualizar compras")
        print("0.Regresar")
        entrada_cliente=input("Seleccione opcion: ")
        if entrada_cliente == "1": 
                idcompra=input("Escriba el codigo de la compra: ")
                productos=input("Escriba el producto: ")
                nombre_cliente=input("Escriba nombre del cliente: ")
                fecha=input("Escriba la fecha: ")
                documento=input("Escriba el documento: ")
                print (agregar_compra(idcompra, productos, nombre_cliente, fecha, documento))

        if entrada_cliente == "2":
            mensaje=requests.get(url_compra)
            print (mensaje.text)
            
            
        if entrada_cliente == "3":
            idcompra=input("Escriba el id de compra: ")
            mensaje=requests.get(url_compra+"/"+idcompra)
            print(mensaje.text)
            
        if entrada_cliente == "4":
            documento=input("Escriba codigo de la compra que quiere eliminar: ")
            mensaje=requests.delete(url_compra+"/"+idcompra)
            print(mensaje.text)

        if entrada_cliente == "5":
            idcompra=input("Escriba codigo de la compra que quiere editar: ")
            mensaje=requests.get(url_compra+"/"+idcompra)
            mensaje=mensaje.json()
            productos_nuevo=input("Escriba el nuevo producto: ")
            nombre_cliente_nuevo=input("Escriba su nombre: ")
            fecha_nuevo=input("Escriba la fecha: ")
            documento_nuevo=input("Escriba el documento: ")


            if productos_nuevo == "":
                productos_nuevo= mensaje["producto"]
            if nombre_cliente_nuevo =="":
                nombre_cliente_nuevo= mensaje["nombre_cliente"]
            if fecha_nuevo == "":
                fecha_nuevo= mensaje["fecha"]
            if documento_nuevo == "":
                documento_nuevo= mensaje["documento"]
            

            print (editar_compra(productos_nuevo, nombre_cliente_nuevo, fecha_nuevo, documento_nuevo))
            
#TIENDA

    if entrada =="4":
        print("********************************************")
        print("MENU DE LA TIENDA:")
        print("********************************************")
        print("1.crear cuenta")
        print("2.comprar producto")
        print("3.salir")
        entrada_cliente=input("Seleccione opcion: ")
        if entrada_cliente == "1":
            documento=input("Escriba su documento: ")
            nombre=input("Escriba su nombre: ")
            apellidos=input("Escriba sus apellidos: ")
            correo=input("Escriba su correo: ")
            telefono=input("Escriba su telefono: ")
            direccion=input("Escriba su direccion: ")
            print (agregar_cliente(documento, nombre, apellidos, correo, telefono, direccion))

        if entrada_cliente =="2":
            documento=input("Escriba su documento: ")
            nombre=input("Escriba su nombre: ")
            mensaje=requests.get(url_inventario)

            mensaje=mensaje.json()
            for i in range(len(mensaje)):
                print("Producto ["+str(i+1)+"]")
                print(" *Nombre artículo: "+mensaje[i]["nombre_producto"])
                print(" *Tipo artículo: "+mensaje[i]["tipo_producto"])
                print(" *Cantidad del artículo: "+mensaje[i]["cantidad_disponible"])
                print(" *Precio del artículo: "+mensaje[i]["precio"])

            nro_compra=input("Escriba el numero del artículo para comprarlo: ")
            cantidad_pedido=input("Seleccione la cantidad que quiere comprar: ")
            cantidad_disponible=int(mensaje[int(nro_compra)-1]["cantidad_disponible"])
            if cantidad_disponible >= int(cantidad_pedido):
                print("Se ha comprado el artículo correctamente")
                idproducto=str(mensaje[int(nro_compra)-1]["codigo_producto"])
                cantidad_nuevo=cantidad_disponible-int(cantidad_pedido)
                editar_producto (mensaje[int(nro_compra)-1]["nombre_producto"], mensaje[int(nro_compra)-1]["tipo_producto"], str(cantidad_nuevo), mensaje[int(nro_compra)-1]["precio"], mensaje[int(nro_compra)-1]["codigo_producto"])
                agregar_compra (str(random.randrange(100)), mensaje[int(nro_compra)-1]["nombre_producto"], nombre, str(datetime.now()), documento)
                print ("Se ha registrado su compra correctamente")
            else:
                print("La cantidad solicitada es mayor a la cantidad disponible")
            


