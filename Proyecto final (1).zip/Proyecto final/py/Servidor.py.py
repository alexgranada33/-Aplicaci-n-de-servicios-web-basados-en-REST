from flask import Flask, request, jsonify, Response
import json
from bson import json_util

lista_documento=[]
lista_inventario=[]
lista_compras=[]

Debug=True
app= Flask(__name__)

#CLIENTE

@app.route('/usuarios', methods =['POST'])

def crear_clientes():
    documento = request.json['documento']
    nombre = request.json['nombre']
    apellidos = request.json['apellidos']
    correo = request.json['correo']
    telefono = request.json['telefono']
    direccion = request.json['direccion']
    for cliente in lista_documento:
        if documento == cliente["documento"]:
            respuesta={
            'mensaje': 'Ya hay un cliente con este documento'
            }
            return respuesta
    
    if documento and nombre and apellidos and correo and telefono and direccion:
        #with open('clientes.json', 'a') as file:
        datos={
                'documento': documento,
                'nombre': nombre,
                'apellidos': apellidos,
                'correo': correo,
                'telefono': telefono,
                'direccion': direccion
                }
            #json.dump(datos, file)
        lista_documento.append(datos)
            
        respuesta={
            'mensaje': 'Se han recibido los datos correctamente'
            }
        return respuesta
    
    else:
        return no_encontrado()
        
    
@app.route('/usuarios', methods=['GET'])

def obtener_clientes():
    response=json_util.dumps(lista_documento)
    return Response(response, mimetype='application/json')

@app.route('/usuarios/<documento>', methods=['GET'])

def buscar_cliente(documento):
    documento=str(documento)
    for cliente in lista_documento:
        if documento == cliente["documento"]:
            response=json_util.dumps(cliente)
            return Response(response, mimetype='application/json')
        
    respuesta={'mensaje': 'No se han encontrado cliente con este documento'}
    return respuesta


@app.route('/usuarios/<documento>', methods=['DELETE'])

def eliminar_cliente(documento):
    documento=str(documento)
    for cliente in lista_documento:
        if documento == cliente["documento"]:
            lista_documento.remove(cliente)
            respuesta={
            'mensaje': 'Se ha eliminado correctamente el usuario con documento: ' +documento
            }
            return respuesta
    respuesta={'mensaje': 'No se ha encontrado ningun cliente con este documento'}
    return respuesta


@app.route('/usuarios/<documento>', methods=['PUT'])

def modificar_cliente(documento):
    documento=str(documento)
    nombre = request.json['nombre']
    apellidos = request.json['apellidos']
    correo = request.json['correo']
    telefono = request.json['telefono']
    direccion = request.json['direccion']
    for cliente in lista_documento:
        if documento == cliente["documento"]:
            cliente["nombre"]=nombre
            cliente["apellidos"]=apellidos
            cliente["correo"]=correo
            cliente["telefono"]=telefono
            cliente["direccion"]=direccion
            respuesta={
            'mensaje': 'Se ha modificado correctamente el usuario con documento: ' +documento
            }
            return respuesta
    respuesta={'mensaje': 'No se ha encontrado ningun cliente con este documento'}
    return respuesta
            
#INVENTARIO

@app.route('/inventario', methods =['POST'])
def crear_producto():
    codigo_producto = request.json['codigo_producto']
    nombre_producto = request.json['nombre_producto']
    tipo_producto = request.json['tipo_producto']
    cantidad_disponible = request.json['cantidad_disponible']
    precio = request.json['precio']
    for producto in lista_inventario:
        if codigo_producto == producto["codigo_producto"]:
            respuesta={
            'mensaje': 'Ya existe un producto con este id'
            }
            return respuesta
    
    if codigo_producto and nombre_producto and tipo_producto and cantidad_disponible and precio:
        datos={
                'codigo_producto': codigo_producto,
                'nombre_producto': nombre_producto,
                'tipo_producto': tipo_producto,
                'cantidad_disponible': cantidad_disponible,
                'precio': precio
                }
            
        lista_inventario.append(datos)
            
        respuesta={
            'mensaje': 'Se han recibido correctamente los datos'
            }
        return respuesta
    
    else:
        return no_encontrado()

@app.route('/inventario', methods=['GET'])

def obtener_producto():
    response=json_util.dumps(lista_inventario)
    return Response(response, mimetype='application/json')


@app.route('/inventario/<codigo_producto>', methods=['GET'])

def buscar_producto(codigo_producto):
    codigo_producto=str(codigo_producto)
    for producto in lista_inventario:
        if codigo_producto == producto["codigo_producto"]:
            response=json_util.dumps(producto)
            return Response(response, mimetype='application/json')
        
    respuesta={'mensaje': 'No se ha encontrado ningun producto con este codigo'}
    return respuesta

@app.route('/inventario/<codigo_producto>', methods=['DELETE'])

def eliminar_producto(codigo_producto):
    codigo_producto=str(codigo_producto)
    for producto in lista_inventario:
        if codigo_producto == producto["codigo_producto"]:
            lista_inventario.remove(producto)
            respuesta={
            'mensaje': 'Se ha eliminado correctamente el producto con ID: ' +codigo_producto
            }
            return respuesta
    respuesta={'mensaje': 'No se ha encontrado ningun producto con este codigo'}
    return respuesta

@app.route('/inventario/<codigo_producto>', methods=['PUT'])

def modificar_producto(codigo_producto):
    codigo_producto=str(codigo_producto)
    nombre_producto = request.json['nombre_producto']
    tipo_producto = request.json['tipo_producto']
    cantidad_disponible = request.json['cantidad_disponible']
    precio = request.json['precio']
    
    for producto in lista_inventario:
        if codigo_producto == producto["codigo_producto"]:
            producto["nombre_producto"]=nombre_producto
            producto["tipo_producto"]=tipo_producto
            producto["cantidad_disponible"]=cantidad_disponible
            producto["precio"]=precio
            respuesta={
            'mensaje': 'Se ha modificado correctamente el producto con codigo: ' +codigo_producto
            }
            return respuesta
    respuesta={'mensaje': 'No se ha encontrado ningun producto con este codigo'}
    return respuesta


#COMPRAS

@app.route('/compras', methods =['POST'])
def crear_compra():
    idcompra = request.json['idcompra']
    productos= request.json['productos']
    nombre_cliente= request.json['nombre_cliente']
    fecha= request.json['fecha']
    documento = request.json['documento']
    for compra in lista_compras:
        if idcompra == compra["idcompra"]:
            respuesta={
            'mensaje': 'Ya existe una compra con este id'
            }
            return respuesta
    if idcompra and productos and documento and nombre_cliente and fecha:
        datos={
                'idcompra': idcompra,
                'productos': productos,
                'documento': documento,
                'nombre_cliente':nombre_cliente,
                'fecha': fecha
                }
            
        lista_compras.append(datos)
            
        respuesta={
            'mensaje': 'Se han recibido correctamente los datos'
            }
        return respuesta
    
    else:
        return no_encontrado()

@app.route('/compras', methods=['GET'])

def obtener_compras():
    response=json_util.dumps(lista_compras)
    return Response(response, mimetype='application/json')


@app.route('/compras/<idcompra>', methods=['GET'])

def buscar_compra(idcompra):
    idcompra=str(idcompra)
    for compra in lista_compras:
        if idcompra == compra["idcompra"]:
            response=json_util.dumps(compra)
            return Response(response, mimetype='application/json')
        
    respuesta={'mensaje': 'No se ha encontrado ninguna compra con este id'}
    return respuesta

@app.route('/compras/<idcompra>', methods=['DELETE'])

def eliminar_compra(idcompra):
    idcompra=str(idcompra)
    for compra in lista_compras:
        if idcompra == compra["idcompra"]:
            lista_compras.remove(compra)
            respuesta={
            'mensaje': 'Se ha eliminado correctamente la compra con ID: ' +idcompra
            }
            return respuesta
    respuesta={'mensaje': 'No se ha encontrado ninguna compra con este id'}
    return respuesta


@app.route('/compras/<idcompra>', methods=['PUT'])

def modificar_compra(idcompra):
    idcompra=str(idcompra)
    productos= request.json['productos']
    nombre_cliente= request.json['nombre_cliente']
    fecha= request.json['fecha']
    documento = request.json['documento']
    
    for compra in lista_compras:
        if idcompra == compra["idcompra"]:
            compra["productos"]=productos
            compra["documento"]=documento
            compra["nombre_cliente"]=nombre_cliente
            compra["fecha"]=fecha
            respuesta={
            'mensaje': 'Se ha modificado correctamente la compra con id: ' +idcompra
            }
            return respuesta
    respuesta={'mensaje': 'No se ha encontrado ningun cliente con esta documento'}
    return respuesta


#MANEJO DE ERRORES
    
@app.errorhandler(404)
def no_encontrado(error=None):
    mensaje=jsonify({
        'mensaje': 'Recurso no encontrado: '+ request.url,
        'status': 404
        })
    mensaje.status_code=404
    return mensaje


if __name__ == "__main__":
    app.run(debug=True)
